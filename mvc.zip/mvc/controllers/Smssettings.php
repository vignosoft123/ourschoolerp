<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Smssettings extends Admin_Controller {
/*
| -----------------------------------------------------
| PRODUCT NAME: 	INILABS SCHOOL MANAGEMENT SYSTEM
| -----------------------------------------------------
| AUTHOR:			INILABS TEAM
| -----------------------------------------------------
| EMAIL:			info@inilabs.net
| -----------------------------------------------------
| COPYRIGHT:		RESERVED BY INILABS IT
| -----------------------------------------------------
| WEBSITE:			http://inilabs.net
| -----------------------------------------------------
*/
	function __construct () {
		parent::__construct();
		$this->load->model("smssettings_m");
		$language = $this->session->userdata('lang');
		$this->lang->load('smssettings', $language);
		if(config_item('demo')) {
            $this->session->set_flashdata('error', 'In demo SMS setting module is disable!');
            redirect(base_url('dashboard/index'));
        }
	}

	protected function rules_clickatell() {
		$rules = array(
			array(
				'field' => 'clickatell_username', 
				'label' => $this->lang->line("smssettings_username"), 
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			), 
			array(
				'field' => 'clickatell_password', 
				'label' => $this->lang->line("smssettings_password"),
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
			array(
				'field' => 'clickatell_api_key', 
				'label' => $this->lang->line("smssettings_api_key"), 
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
		);
		return $rules;
	}

	protected function rules_twilio() {
		$rules = array(
			array(
				'field' => 'twilio_accountSID', 
				'label' => $this->lang->line("smssettings_accountSID"), 
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			), 
			array(
				'field' => 'twilio_authtoken', 
				'label' => $this->lang->line("smssettings_authtoken"),
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
			array(
				'field' => 'twilio_fromnumber', 
				'label' => $this->lang->line("smssettings_fromnumber"), 
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
		);
		return $rules;
	}

	protected function rules_bulk() {
		$rules = array(
			array(
				'field' => 'bulk_username', 
				'label' => $this->lang->line("smssettings_username"), 
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			) 
// 			array(
// 				'field' => 'bulk_password', 
// 				'label' => $this->lang->line("smssettings_password"),
// 				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
// 			)
		);
		return $rules;
	}

	protected function rules_msg91() {
		$rules = array(
			array(
				'field' => 'msg91_username',
				'label' => 'Username',
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
			array(
				'field' => 'msg91_password',
				'label' => 'Password',
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
			array(
				'field' => 'msg91_PEID',
				'label' => 'PEID',
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			),
			array(
				'field' => 'msg91_senderID',
				'label' => $this->lang->line("smssettings_senderID"),
				'rules' => 'trim|xss_clean|max_length[255]|callback_unique_field'
			)
		);
		return $rules;
	}

	public function unique_field($field) {
        if($this->input->post('type') == 'clickatell') {
            if(!empty($this->input->post('clickatell_username')) || !empty($this->input->post('clickatell_password')) || !empty($this->input->post('clickatell_api_key'))) {

            	if($this->input->post('clickatell_username') == $field) {
            		if($this->input->post('clickatell_username') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	} 

            	if($this->input->post('clickatell_password') == $field) {
            		if($this->input->post('clickatell_password') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	} 

            	if($this->input->post('clickatell_api_key') == $field) {
            		if($this->input->post('clickatell_api_key') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	} 

            	return TRUE;
            } 
            return TRUE;
        } elseif($this->input->post('type') == 'twilio') {
        	if(!empty($this->input->post('twilio_accountSID')) || !empty($this->input->post('twilio_authtoken')) || !empty($this->input->post('twilio_fromnumber'))) {

        		if($this->input->post('twilio_accountSID') == $field) {
            		if($this->input->post('twilio_accountSID') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	} 

            	if($this->input->post('twilio_authtoken') == $field) {
            		if($this->input->post('twilio_authtoken') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	} 

            	if($this->input->post('twilio_fromnumber') == $field) {
            		if($this->input->post('twilio_fromnumber') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	}

            	return TRUE; 
            }
            return TRUE;
        } elseif($this->input->post('type') == 'bulk') {
        	if(!empty($this->input->post('bulk_username')) || !empty($this->input->post('bulk_password'))) {

        		if($this->input->post('bulk_username') == $field) {
            		if($this->input->post('bulk_username') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	} 

            // 	if($this->input->post('bulk_password') == $field) {
            // 		if($this->input->post('bulk_password') == '') {
	           // 		$this->form_validation->set_message("unique_field", "The %s is required.");
	           //     	return FALSE;
            // 		}
            // 		return TRUE;
            // 	} 

            	return TRUE;
            }
            return TRUE;
        } elseif($this->input->post('type') == 'msg91') {
        	if(!empty($this->input->post('msg91_username')) || !empty($this->input->post('msg91_senderID'))) {

        		if($this->input->post('msg91_username') == $field) {
            		if($this->input->post('msg91_username') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	}
            	
            	if($this->input->post('msg91_password') == $field) {
            		if($this->input->post('msg91_password') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	}

            	if($this->input->post('msg91_senderID') == $field) {
            		if($this->input->post('msg91_senderID') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	}
            	
            	if($this->input->post('msg91_PEID') == $field) {
            		if($this->input->post('msg91_PEID') == '') {
	            		$this->form_validation->set_message("unique_field", "The %s is required.");
	                	return FALSE;
            		}
            		return TRUE;
            	}

            	return TRUE;
            }
            return TRUE;
        }
    }

	public function index() {

		$this->insert_smssettings_data();
		
		$clickatell_bind = array();
		$get_clickatells = $this->smssettings_m->get_order_by_clickatell();
		foreach ($get_clickatells as $key => $get_clickatell) {
			$clickatell_bind[$get_clickatell->field_names] = $get_clickatell->field_values;
		}
		$this->data['set_clickatell'] = $clickatell_bind;

		$twilio_bind = array();
		$get_twilios = $this->smssettings_m->get_order_by_twilio();
		foreach ($get_twilios as $key => $get_twilio) {
			$twilio_bind[$get_twilio->field_names] = $get_twilio->field_values;
		}
		$this->data['set_twilio'] = $twilio_bind;

		$bulk_bind = array();
		$get_bulks = $this->smssettings_m->get_order_by_bulk();
		foreach ($get_bulks as $key => $get_bulk) {
			$bulk_bind[$get_bulk->field_names] = $get_bulk->field_values;
		}
		$this->data['set_bulk'] = $bulk_bind;

        $msg91_bind = array();
		$get_msg91s = $this->smssettings_m->get_order_by_msg91();
		foreach ($get_msg91s as $key => $get_msg91) {
			$msg91_bind[$get_msg91->field_names] = $get_msg91->field_values;
		}
		$this->data['set_msg91'] = $msg91_bind;

		$whatsapp_bind = array();
		$get_whatsapps = $this->smssettings_m->get_order_by_whatsapp();
		foreach ($get_whatsapps as $key => $get_whatsapp) {
			$whatsapp_bind[$get_whatsapp->field_names] = $get_whatsapp->field_values;
		}
		$this->data['set_whatsapp'] = $whatsapp_bind;


		if($_POST) {
			$type = $this->input->post('type');
			if($type == 'clickatell') {
				$this->data['clickatell'] = 1;
				$this->data['twilio'] = 0;
				$this->data['bulk'] = 0;
				$this->data['msg91'] = 0;

				$rules = $this->rules_clickatell();
				$this->form_validation->set_rules($rules);
				if ($this->form_validation->run() == FALSE) {
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);			
				} else {

					$username = $this->input->post('clickatell_username');
					$password = $this->input->post('clickatell_password');
					$api_key = $this->input->post('clickatell_api_key');

					$array = array(
					   array(
					      'field_names' => 'clickatell_username',
					      'field_values' => $username
					   ),
					   array(
					      'field_names' => 'clickatell_password',
					      'field_values' => $password
					   ),
					   array(
					      'field_names' => 'clickatell_api_key',
					      'field_values' => $api_key
					   )
					);

					$this->smssettings_m->update_clickatell($array);
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);
				}
			} elseif($type == 'twilio') {
				$this->data['clickatell'] = 0;
				$this->data['twilio'] = 1;
				$this->data['bulk'] = 0;
                $this->data['msg91'] = 0;

				$rules = $this->rules_twilio();
				$this->form_validation->set_rules($rules);
				if ($this->form_validation->run() == FALSE) {
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);			
				} else {
					$accountSID = $this->input->post('twilio_accountSID');
					$authtoken = $this->input->post('twilio_authtoken');
					$fromnumber = $this->input->post('twilio_fromnumber');

					$array = array(
					   array(
					      'field_names' => 'twilio_accountSID',
					      'field_values' => $accountSID
					   ),
					   array(
					      'field_names' => 'twilio_authtoken',
					      'field_values' => $authtoken
					   ),
					   array(
					      'field_names' => 'twilio_fromnumber',
					      'field_values' => $fromnumber
					   )
					);

					$this->smssettings_m->update_twilio($array);
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);
				}
			} elseif($type == 'whatsapp') {
				$this->data['clickatell'] = 0;
				$this->data['twilio'] = 0;
				$this->data['bulk'] = 0;
                $this->data['msg91'] = 0;
                $this->data['whatsapp'] = 1;

				$rules = $this->rules_bulk();
				$this->form_validation->set_rules($rules);
				if ($this->form_validation->run() == FALSE) {
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);			
				} else {
					 
					$whatsapp_user = $this->input->post('whatsapp_user');
					$whatsapp_password = $this->input->post('whatsapp_password');
					$whatsapp_sender = $this->input->post('whatsapp_sender');

					// $this->db->where('field_names',"whatsapp_link_number");
					// $num_cnt = $this->db->get('smssettings')->num_rows();
					// if($num_cnt == 0){
					// 	$this->db->query("INSERT INTO `smssettings` (`smssettingsID`, `types`, `field_names`, `field_values`, `smssettings_extra`) VALUES (NULL, 'whatsapp', 'whatsapp_link_number', '', NULL)");
					// }

					$array = array(
						array(
						   'field_names' => 'whatsapp_user',
						   'field_values' => $whatsapp_user
						),
						array(
                            'field_names' => 'whatsapp_password',
                            'field_values' => $whatsapp_password
                        ), 
						array(
                            'field_names' => 'whatsapp_sender',
                            'field_values' => $whatsapp_sender
                        ), 
					 );
 
					 $this->smssettings_m->update_bulk($array);

					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);
				}
			} elseif($type == 'bulk') {
				$this->data['clickatell'] = 0;
				$this->data['twilio'] = 0;
				$this->data['bulk'] = 1;
                $this->data['msg91'] = 0;

				$rules = $this->rules_bulk();
				$this->form_validation->set_rules($rules);
				if ($this->form_validation->run() == FALSE) {
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);			
				} else {
					$username = $this->input->post('bulk_username');
				// 	$password = $this->input->post('bulk_password');

					$array = array(
					   array(
					      'field_names' => 'bulk_username',
					      'field_values' => $username
					   )
					   //array(
					   //   'field_names' => 'bulk_password',
					   //   'field_values' => $password
					   //)
					);

					$this->smssettings_m->update_bulk($array);
					$this->data["subview"] = "smssettings/index";
					$this->load->view('_layout_main', $this->data);
				}
			} elseif($type == 'msg91') {
                $this->data['clickatell'] = 0;
                $this->data['twilio'] = 0;
                $this->data['bulk'] = 0;
                $this->data['msg91'] = 1;

                $rules = $this->rules_msg91();
                $this->form_validation->set_rules($rules);
                if ($this->form_validation->run() == FALSE) {
                    $this->data["subview"] = "smssettings/index";
                    $this->load->view('_layout_main', $this->data);
                } else {
                    $authKey = $this->input->post('msg91_username');
                    $senderID = $this->input->post('msg91_senderID');
                    $msg91_register_school_name = trim($this->input->post('msg91_register_school_name')," ");
                    $password = $this->input->post('msg91_password');
                    $PEID = $this->input->post('msg91_PEID');

                    $array = array(
                        array(
                            'field_names' => 'msg91_username',
                            'field_values' => $authKey
                        ),
                        array(
                            'field_names' => 'msg91_password',
                            'field_values' => $password
                        ),
                        array(
                            'field_names' => 'msg91_PEID',
                            'field_values' => $PEID
                        ),
                        array(
                            'field_names' => 'msg91_senderID',
                            'field_values' => $senderID
                        ),
                        array(
                            'field_names' => 'msg91_register_school_name',
                            'field_values' => $msg91_register_school_name
                        )
                    );

                    $this->smssettings_m->update_msg91($array);
                    $this->data["subview"] = "smssettings/index";
                    $this->load->view('_layout_main', $this->data);
                }
            } 

		} else {
			$this->data['clickatell'] = 0;
			$this->data['twilio'] = 0;
			$this->data['bulk'] = 0;
			$this->data['msg91'] = 1;

			$this->data["subview"] = "smssettings/index";
			$this->load->view('_layout_main', $this->data);
		}
	}

	//code for send whatsapp msg -srinu
	public function send_whatsapp_msg($array){
		// echo "<pre>";print_r($array);die;
		
		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => 'https://voice.vignosoft.com/api_v2/whats-app/send',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS => 'https://voice.vignosoft.com/api_v2/whats-app/send?api_key=gjK_1igpeGdsHGJwvN1u_c7-QZ7RFyGKFOClGgYMmdVxi7yrkysOK-0nRUFb9-cE&type=broadcast&country_code=IN&wa_number='.$array["whatsapp_number"].'&mobile_numbers=7569996118&content='.$array["whatsapp_msg"],
		CURLOPT_HTTPHEADER => array(
			'AuthorizationKey: Bearer gjK_1igpeGdsHGJwvN1u_c7-QZ7RFyGKFOClGgYMmdVxi7yrkysOK-0nRUFb9-cE',
			'Content-Type: application/x-www-form-urlencoded'
		),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		return $response;
	}

	public function insert_smssettings_data() {
		// Define the data to insert
		$data = [
			['types' => 'whatsapp', 'field_names' => 'whatsapp_user'],
			['types' => 'whatsapp', 'field_names' => 'whatsapp_password'],
			['types' => 'whatsapp', 'field_names' => 'whatsapp_sender']
		];
	
		// Insert only if the records do not exist
		foreach ($data as $row) {
			$this->db->where($row);
			$query = $this->db->get('smssettings');
	
			if ($query->num_rows() == 0) {
				$this->db->insert('smssettings', $row);
				// echo "Inserted: " . json_encode($row) . "<br>";
			} else {
				// echo "Already exists: " . json_encode($row) . "<br>";
			}
		}
	}
	

	
}

/* End of file student.php */
/* Location: .//D/xampp/htdocs/school/mvc/controllers/student.php */