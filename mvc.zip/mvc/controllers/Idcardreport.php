<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Idcardreport extends Admin_Controller {
/*
| -----------------------------------------------------
| PRODUCT NAME: 	INILABS SCHOOL MANAGEMENT SYSTEM
| -----------------------------------------------------
| AUTHOR:			INILABS TEAM
| -----------------------------------------------------
| EMAIL:			info@inilabs.net
| -----------------------------------------------------
| COPYRIGHT:		RESERVED BY INILABS IT
| -----------------------------------------------------
| WEBSITE:			http://iNilabs.net
| -----------------------------------------------------
*/
	function __construct() {
		parent::__construct();
        $this->load->model('usertype_m');
        $this->load->model('classes_m');
        $this->load->model('section_m');
        $this->load->model('user_m');
        $this->load->model('systemadmin_m');
        $this->load->model('studentrelation_m');
        $this->load->model('teacher_m');
        $this->load->model('schoolyear_m');
		$this->load->model('Setting_m');

		$language = $this->session->userdata('lang');
		$this->lang->load('idcardreport', $language);
	}

    protected function rules($usertypeID) {
        $rules = array(
            array(
                'field' => 'usertypeID',
                'label' => $this->lang->line('idcardreport_idcard'),
                'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            ),
            // array(
            //     'field' => 'type',
            //     'label' => $this->lang->line('idcardreport_type'),
            //     'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            // ), array(
            //     'field' => 'background',
            //     'label' => $this->lang->line('idcardreport_background'),
            //     'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            // )
        );

        if($usertypeID == 3) {
            $rules[] = array(
                'field' => 'classesID', 
                'label' => $this->lang->line('idcardreport_class'),
                'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            );

            $rules[] = array(
                'field' => 'sectionID',
                'label' => $this->lang->line('idcardreport_section'),
                'rules' => 'trim|xss_clean|greater_than_equal_to[0]'
            );
        }
        return $rules;
    }

    protected function send_pdf_to_mail_rules($usertypeID) {
        $rules = array(
            array(
                'field' => 'usertypeID',
                'label' => $this->lang->line('idcardreport_idcard'),
                'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            ), array(
                'field' => 'type',
                'label' => $this->lang->line('idcardreport_type'),
                'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            ), array(
                'field' => 'background',
                'label' => $this->lang->line('idcardreport_background'),
                'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            ), array(
                'field' => 'to',
                'label' => $this->lang->line('idcardreport_to'),
                'rules' => 'trim|required|xss_clean|valid_email'
            ), array(
                'field' => 'subject',
                'label' => $this->lang->line('idcardreport_subject'),
                'rules' => 'trim|required|xss_clean'
            ), array(
                'field' => 'message',
                'label' => $this->lang->line('idcardreport_message'),
                'rules' => 'trim|xss_clean'
            )
        );
        if($usertypeID == 3) {
            $rules[] = array(
                'field' => 'classesID', 
                'label' => $this->lang->line('idcardreport_class'),
                'rules' => 'trim|required|xss_clean|numeric|callback_unique_data'
            );

            $rules[] = array(
                'field' => 'sectionID',
                'label' => $this->lang->line('idcardreport_section'),
                'rules' => 'trim|xss_clean|greater_than_equal_to[0]'
            );
        }
        return $rules;
    }

    public function unique_data($data) {
        if($data != '') {
            if($data == 0) {
                $this->form_validation->set_message('unique_data','The %s field is required.');
                return FALSE;
            }
            return TRUE;
        } 
        return TRUE;
    }

    public function getSection() {
        $id = $this->input->post('id');
        if((int)$id) {
            $sections = $this->section_m->general_get_order_by_section(array('classesID' => $id));
            echo "<option value='0'>".$this->lang->line("idcardreport_please_select")."</option>";
            if(customCompute($sections)) {
                foreach ($sections as $section) {
                    echo "<option value='".$section->sectionID."'>".$section->section."</option>";
                }
            }
        }
    }

    public function getStudentByClass() {
        $usertypeID = $this->input->post('usertypeID');
        $classesID = $this->input->post('classesID');
        if(((int)$usertypeID && $usertypeID == 3) && ((int)$classesID && $classesID > 0)) {
            $queryArray['srschoolyearID'] = $this->session->userdata('defaultschoolyearID');
            $queryArray['srclassesID'] = $classesID;
            $users = $this->studentrelation_m->general_get_order_by_student($queryArray);
            if(customCompute($users)) {
                echo "<option value='0'>".$this->lang->line("idcardreport_please_select")."</option>";
                foreach ($users as $user) {
                    echo "<option value='".$user->srstudentID."'>".$user->srname."</option>";
                }
            }  
        }
    }

    public function getStudentBySection() {
        $usertypeID = $this->input->post('usertypeID');
        $classesID = $this->input->post('classesID');
        $sectionID = $this->input->post('sectionID');
        if(((int)$usertypeID && $usertypeID == 3) && ((int)$classesID && $classesID > 0)) {
            $queryArray['srschoolyearID'] = $this->session->userdata('defaultschoolyearID');
            $queryArray['srclassesID'] = $classesID;
            if((int)$sectionID && $sectionID > 0) {
                $queryArray['srsectionID'] = $sectionID;
            }
            $users = $this->studentrelation_m->general_get_order_by_student($queryArray);
            if(customCompute($users)) {
                echo "<option value='0'>".$this->lang->line("idcardreport_please_select")."</option>";
                foreach ($users as $user) {
                    echo "<option value='".$user->srstudentID."'>".$user->srname."</option>";
                }
            }  
        }
    }

    public function getUser() {
        $usertypeID = $this->input->post('usertypeID');
        $classesID = $this->input->post('classesID');
        $sectionID = $this->input->post('sectionID');

        if((int)$usertypeID && ((int)$classesID || $classesID == 0) && ((int)$sectionID || $sectionID ==0)) {
            echo "<option value='0'>".$this->lang->line("idcardreport_please_select")."</option>";
            if($usertypeID == 1) {
                $users = $this->systemadmin_m->get_systemadmin();
                if(customCompute($users)) {
                    foreach ($users as $user) {
                        echo "<option value='".$user->systemadminID."'>".$user->name."</option>";
                    }
                }
            } elseif($usertypeID == 2) {
                $users = $this->teacher_m->general_get_teacher();
                 if(customCompute($users)) {
                    foreach ($users as $user) {
                        echo "<option value='".$user->teacherID."'>".$user->name."</option>";
                    }
                }
            } elseif($usertypeID == 3) {
                $users = [];
            } elseif($usertypeID == 4) {
                $users = [];
            } else {
                $users = $this->user_m->get_order_by_user(array('usertypeID' => $usertypeID));
                if(customCompute($users)) {
                    foreach ($users as $user) {
                        echo "<option value='".$user->userID."'>".$user->name."</option>";
                    }
                }
            }
        }
    }

    private function sanitizeIdcardFontStyle($posts) {
        $allowedFontFamilies = array(
            'Arial, sans-serif',
            "'Times New Roman', serif",
            'Verdana, sans-serif',
            'Georgia, serif',
            "'Courier New', monospace",
            "'Trebuchet MS', sans-serif",
            "'Revue', cursive",
            "'Bookman Old Style', serif",
            "'Souvenir', serif",
            'Tahoma, sans-serif',
            'Impact, sans-serif',
            "'Bauhaus 93', sans-serif",
            "'Bazooka', fantasy",
            "'Belwe Bd BT', serif",
            "'Benguiat', serif",
            "'Arial Rounded MT Bold', Arial, sans-serif",
            "'Futura', sans-serif",
            "'Running Matter Ki', fantasy",
        );

        $fontFamily = isset($posts['fontFamily']) && in_array($posts['fontFamily'], $allowedFontFamilies)
            ? $posts['fontFamily']
            : 'Arial, sans-serif';

        $fontSize = isset($posts['fontSize']) && is_numeric($posts['fontSize']) && $posts['fontSize'] >= 10 && $posts['fontSize'] <= 40
            ? (int)$posts['fontSize']
            : 15;

        $labelColor = isset($posts['labelColor']) && preg_match('/^#[0-9a-fA-F]{6}$/', $posts['labelColor'])
            ? $posts['labelColor']
            : '#000000';

        $valueColor = isset($posts['valueColor']) && preg_match('/^#[0-9a-fA-F]{6}$/', $posts['valueColor'])
            ? $posts['valueColor']
            : '#000000';

        $photoBorderColor = isset($posts['photoBorderColor']) && preg_match('/^#[0-9a-fA-F]{6}$/', $posts['photoBorderColor'])
            ? $posts['photoBorderColor']
            : '#000000';

        return array(
            'fontFamily'       => $fontFamily,
            'fontSize'         => $fontSize,
            'bold'             => !empty($posts['fontBold']),
            'italic'           => !empty($posts['fontItalic']),
            'labelColor'       => $labelColor,
            'valueColor'       => $valueColor,
            'photoBorderColor' => $photoBorderColor,
        );
    }

    private function defaultFieldsFor($usertypeID) {
        if ($usertypeID == 3) {
            return array('medium', 'class_section', 'father_name', 'contact_no', 'village', 'blood_group');
        } elseif ($usertypeID == 2) {
            return array('designation', 'contact_no', 'village', 'employee_id');
        }
        return array('role', 'contact_no', 'village', 'employee_id');
    }

    private function queryArray($posts) {
        // echo "<pre>";print_r($posts);die;
        $usertypeID = $posts['usertypeID'];
        $classesID  = $posts['classesID'];
        $sectionID  = $posts['sectionID'];
        $userID     = isset($posts['userID']) ? $posts['userID'] : 0;
        $photo_type     = isset($posts['photo_type']) ? $posts['photo_type'] : 0;

        $queryArray = [];
        if($usertypeID == 1) {
            if($userID > 0) {
                $queryArray['systemadminID'] = $userID;
            }
            $users = $this->systemadmin_m->get_order_by_systemadmin($queryArray);
        } elseif($usertypeID == 2) {
            if($userID > 0) {
                $queryArray['teacherID'] = $userID;
            }
            $users = $this->teacher_m->general_get_order_by_teacher($queryArray);
        } elseif($usertypeID == 3) {
            $queryArray['srschoolyearID'] = $this->session->userdata('defaultschoolyearID');
            $queryArray['srclassesID'] = $classesID;
            if($sectionID > 0) {
                $queryArray['srsectionID'] = $sectionID;
            }
            // Support single or multiple selected students
            if(is_array($userID) && customCompute($userID)) {
                // pass array to model method that handles where_in for student IDs
                $queryArray['srstudentID'] = $userID;
                $users = $this->studentrelation_m->general_get_order_by_student_multi_selction($queryArray, FALSE, $photo_type);
            } else {
                if($userID > 0) {
                    $queryArray['srstudentID'] = $userID;
                }
                $users = $this->studentrelation_m->general_get_order_by_student($queryArray, FALSE, $photo_type);
            }
        } elseif($usertypeID == 4) {
            $users = [];
        } else {
            $queryArray['usertypeID'] = $usertypeID;
            if($userID > 0) {
                $queryArray['userID'] = $userID;
            }
            $users = $this->user_m->get_order_by_user($queryArray);
        }
        return $users;
    }

    public function index_bkp() {
        $this->data['headerassets'] = array(
            'css' => array(
                'assets/select2/css/select2.css',
                'assets/select2/css/select2-bootstrap.css',
            ),
            'js' => array(
                'assets/select2/select2.js',
            )
        );
        $this->data['usertypes'] = $this->usertype_m->get_usertype();
        $this->data['classes'] = $this->classes_m->general_get_classes();
        $this->data["subview"] = "report/idcard/IdcardReportView";
        $this->load->view('_layout_main', $this->data);
    }

    public function index() {
        $this->data['headerassets'] = array(
            'css' => array(
                'assets/select2/css/select2.css',
                'assets/select2/css/select2-bootstrap.css',
            ),
            'js' => array(
                'assets/select2/select2.js',
            )
        );
        $this->data['usertypes'] = $this->usertype_m->get_usertype();
        $this->data['classes'] = $this->classes_m->general_get_classes();
        $this->data["subview"] = "report/idcard/IdcardReportView_new";
        $this->load->view('_layout_main', $this->data);
    }

     public function low_dimensions() {
        $this->data['headerassets'] = array(
            'css' => array(
                'assets/select2/css/select2.css',
                'assets/select2/css/select2-bootstrap.css',
            ),
            'js' => array(
                'assets/select2/select2.js',
            )
        );
        $this->data['usertypes'] = $this->usertype_m->get_usertype();
        $this->data['classes'] = $this->classes_m->general_get_classes();
        $this->data["subview"] = "report/idcard/IdcardReportView_new_low_dimensions";
        $this->load->view('_layout_main', $this->data);
    }

    public function getIdcardReport() {
        $retArray['status'] = FALSE;
        $retArray['render'] = '';
        if(permissionChecker('idcardreport')) {
            if($_POST) {
                // echo "<PRE>aaaa";print_r($_POST);die;
                $usertypeID = $this->input->post('usertypeID');
                $rules = $this->rules($usertypeID);
                $this->form_validation->set_rules($rules);
                if ($this->form_validation->run() == FALSE) {
                    $retArray = $this->form_validation->error_array();
                    $retArray['status'] = FALSE;
                    echo json_encode($retArray);
                    exit;
                } else {
                    $schoolyearID = $this->session->userdata('defaultschoolyearID');
                    $this->data['usertypeID']  = $usertypeID;
                    $this->data['classesID']   = $this->input->post('classesID');
                    $this->data['sectionID']   = $this->input->post('sectionID');
                    $this->data['userID']      = $this->input->post('userID');
                    $this->data['type']        = $this->input->post('type');
                    $this->data['background']  = $this->input->post('background');
                    $this->data['photo_type']  = $this->input->post('photo_type');
                    $this->data['schoolyear'] = $this->schoolyear_m->get_single_schoolyear(array('schoolyearID'=>$schoolyearID));
                    $this->data['classes']     = pluck($this->classes_m->general_get_classes(),'classes','classesID');
                    $this->data['sections']    = pluck($this->section_m->general_get_section(),'section','sectionID');
                    $this->data['usertypes']   = pluck($this->usertype_m->get_usertype(),'usertype','usertypeID');
                    $this->data['idcards']     = $this->queryArray($this->input->post());
                    $retArray['status'] = TRUE;

					 $this->data['id_card_template'] = $this->Setting_m->get_setting_where('id_card_template');

                    $selectedFields = $this->input->post('fields');
                    $this->data['selectedFields'] = (is_array($selectedFields) && customCompute($selectedFields))
                        ? $selectedFields
                        : $this->defaultFieldsFor($usertypeID);

                    $this->data['fontStyle'] = $this->sanitizeIdcardFontStyle($this->input->post());

                    //echo "<pre>";print_r($this->data['idcards']);die;
                    // $retArray['render'] = $this->load->view('report/idcard/IdcardReport', $this->data,true);
                $retArray['render'] = $this->load->view('report/idcard/IdcardReport_new', $this->data,true);

                    echo json_encode($retArray);
                    exit;
                }
            } else {
                $retArray['status'] = TRUE;
                $retArray['render'] =  $this->load->view('report/reporterror', $this->data, true);
                echo json_encode($retArray);
                exit;
            }
        } else {
            $retArray['status'] = TRUE;
            $retArray['render'] =  $this->load->view('report/reporterror', $this->data, true);
            echo json_encode($retArray);
            exit;
        }
    }


    public function getIdcardReport_low_dimensions() {
        $retArray['status'] = FALSE;
        $retArray['render'] = '';
        if(permissionChecker('idcardreport')) {
            if($_POST) {
                // echo "<PRE>aaaa";print_r($_POST);die;
                $usertypeID = $this->input->post('usertypeID');
                $rules = $this->rules($usertypeID);
                $this->form_validation->set_rules($rules);
                if ($this->form_validation->run() == FALSE) {
                    $retArray = $this->form_validation->error_array();
                    $retArray['status'] = FALSE;
                    echo json_encode($retArray);
                    exit;
                } else {
                    $schoolyearID = $this->session->userdata('defaultschoolyearID');
                    $this->data['usertypeID']  = $usertypeID;
                    $this->data['classesID']   = $this->input->post('classesID');
                    $this->data['sectionID']   = $this->input->post('sectionID');
                    $this->data['userID']      = $this->input->post('userID');
                    $this->data['type']        = $this->input->post('type');
                    $this->data['background']  = $this->input->post('background');
                    $this->data['photo_type']  = $this->input->post('photo_type');
                    $this->data['schoolyear'] = $this->schoolyear_m->get_single_schoolyear(array('schoolyearID'=>$schoolyearID));
                    $this->data['classes']     = pluck($this->classes_m->general_get_classes(),'classes','classesID');
                    $this->data['sections']    = pluck($this->section_m->general_get_section(),'section','sectionID');
                    $this->data['usertypes']   = pluck($this->usertype_m->get_usertype(),'usertype','usertypeID');
                    $this->data['idcards']     = $this->queryArray($this->input->post());
                    $retArray['status'] = TRUE;

					 $this->data['id_card_template'] = $this->Setting_m->get_setting_where('id_card_template');

                    //echo "<pre>";print_r($this->data['idcards']);die;
                    // $retArray['render'] = $this->load->view('report/idcard/IdcardReport', $this->data,true);
                $retArray['render'] = $this->load->view('report/idcard/IdcardReport_low_dimensions', $this->data,true);

                    echo json_encode($retArray);
                    exit;
                }
            } else {
                $retArray['status'] = TRUE;
                $retArray['render'] =  $this->load->view('report/reporterror', $this->data, true);
                echo json_encode($retArray);
                exit;
            }
        } else {
            $retArray['status'] = TRUE;
            $retArray['render'] =  $this->load->view('report/reporterror', $this->data, true);
            echo json_encode($retArray);
            exit;
        }
    }

    public function getIdcardReport_new()
{
    $retArray['status'] = FALSE;
    $retArray['render'] = '';

    if(permissionChecker('idcardreport')) {
        if($_POST) {
            $usertypeID = $this->input->post('usertypeID');
            $rules      = $this->rules($usertypeID);
            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() == FALSE) {
                $retArray = $this->form_validation->error_array();
                $retArray['status'] = FALSE;
                echo json_encode($retArray);
                exit;
            } else {
                $schoolyearID           = $this->session->userdata('defaultschoolyearID');
                $this->data['usertypeID']  = $usertypeID;
                $this->data['classesID']   = $this->input->post('classesID');
                $this->data['sectionID']   = $this->input->post('sectionID');
                $this->data['userID']      = $this->input->post('userID'); // optional
                $this->data['type']        = $this->input->post('type');
                $this->data['background']  = $this->input->post('background');

                $this->data['schoolyear']  = $this->schoolyear_m->get_single_schoolyear([
                    'schoolyearID'=>$schoolyearID
                ]);

                $this->data['classes']     = pluck($this->classes_m->general_get_classes(),'classes','classesID');
                $this->data['sections']    = pluck($this->section_m->general_get_section(),'section','sectionID');
                $this->data['usertypes']   = pluck($this->usertype_m->get_usertype(),'usertype','usertypeID');

                // ✅ Fetch students of given class & section
                $this->load->model('student_m');
                $this->data['idcards']     = $this->queryArray($this->input->post());
                
            //  $this->data['idcards'] = $this->student_m->get_order_by_student([
                //     'classesID'   => $this->data['classesID'],
                //     'sectionID'   => $this->data['sectionID'],
                //     'schoolyearID'=> $schoolyearID
                // ]);

                $retArray['status'] = TRUE;
                $retArray['render'] = $this->load->view('report/idcard/IdcardReport_new', $this->data,true);
                echo json_encode($retArray);
                exit;
            }
        } else {
            $retArray['status'] = TRUE;
            $retArray['render'] =  $this->load->view('report/reporterror', $this->data, true);
            echo json_encode($retArray);
            exit;
        }
    } else {
        $retArray['status'] = TRUE;
        $retArray['render'] =  $this->load->view('report/reporterror', $this->data, true);
        echo json_encode($retArray);
        exit;
    }
}


    public function pdf() {
        if(permissionChecker('idcardreport')) {
            $usertypeID   = htmlentities(escapeString($this->uri->segment(3)));
            $classesID    = htmlentities(escapeString($this->uri->segment(4)));
            $sectionID    = htmlentities(escapeString($this->uri->segment(5)));
            $userID       = htmlentities(escapeString($this->uri->segment(6)));
            $type         = htmlentities(escapeString($this->uri->segment(7)));
            $background   = htmlentities(escapeString($this->uri->segment(8)));
            $schoolyearID = $this->session->userdata('defaultschoolyearID');

            if((int)$usertypeID && ((int)$classesID || $classesID ==0) && ((int)$sectionID || $sectionID ==0) && ((int)$userID || $userID ==0) && (int)$type && (int)$background) {
                $this->data['usertypeID']  = $usertypeID;
                $this->data['classesID']   = $classesID;
                $this->data['sectionID']   = $sectionID;
                $this->data['userID']      = $userID;
                $this->data['type']        = $type;
                $this->data['background']  = $background;
                $this->data['schoolyear']  = $this->schoolyear_m->get_single_schoolyear(array('schoolyearID'=>$schoolyearID));
                $this->data['classes']     = pluck($this->classes_m->general_get_classes(),'classes','classesID');
                $this->data['sections']    = pluck($this->section_m->general_get_section(),'section','sectionID');
                $array['usertypeID'] = $usertypeID;
                $array['classesID'] = $classesID;
                $array['sectionID'] = $sectionID;
                $array['userID'] = $userID;
                $this->data['idcards']     = $this->queryArray($array);
                $this->reportPDF('idcardreport.css', $this->data, 'report/idcard/IdcardReportPDF','view','a4');
            } else {
                $this->data["subview"] = "error";
                $this->load->view('_layout_main', $this->data);
            }
        } else {
            $this->data["subview"] = "error";
            $this->load->view('_layout_main', $this->data);
        }
    }

    public function send_pdf_to_mail() {
        $retArray['status'] = FALSE;
        $retArray['message'] = '';

        if(permissionChecker('idcardreport')) {
            if($_POST) {
                $to          = $this->input->post('to');
                $subject     = $this->input->post('subject');
                $message     = $this->input->post('message');
                $usertypeID  = $this->input->post('usertypeID');
                $classesID   = $this->input->post('classesID');
                $sectionID   = $this->input->post('sectionID');
                $userID      = $this->input->post('userID');
                $type        = $this->input->post('type');
                $background  = $this->input->post('background');
                $schoolyearID= $this->session->userdata('defaultschoolyearID');
                $rules = $this->send_pdf_to_mail_rules($usertypeID);
                $this->form_validation->set_rules($rules);
                if ($this->form_validation->run() == FALSE) {
                    $retArray = $this->form_validation->error_array();
                    $retArray['status'] = FALSE;
                    echo json_encode($retArray);
                    exit;
                } else {
                    if((int)$usertypeID && ((int)$classesID || $classesID ==0) && ((int)$sectionID || $sectionID ==0) && ((int)$userID || $userID ==0) && (int)$type && (int)$background) {
                        $this->data['usertypeID']  = $usertypeID;
                        $this->data['classesID']   = $classesID;
                        $this->data['sectionID']   = $sectionID;
                        $this->data['userID']      = $userID;
                        $this->data['type']        = $type;
                        $this->data['background']  = $background;
                        $this->data['schoolyear'] = $this->schoolyear_m->get_single_schoolyear(array('schoolyearID'=>$schoolyearID));
                        $this->data['classes']     = pluck($this->classes_m->general_get_classes(),'classes','classesID');
                        $this->data['sections']    = pluck($this->section_m->general_get_section(),'section','sectionID');
                        $array['usertypeID'] = $usertypeID;
                        $array['classesID'] = $classesID;
                        $array['sectionID'] = $sectionID;
                        $array['userID'] = $userID;
                        $this->data['idcards']     = $this->queryArray($array);
                        $this->reportSendToMail('idcardreport.css', $this->data, 'report/idcard/IdcardReportPDF', $to, $subject, $message);
                        $retArray['message'] = "Message";
                        $retArray['status'] = TRUE;
                        echo json_encode($retArray);
                        exit;
                    } else {
                        $retArray['message'] = $this->lang->line('idcardreport_data_not_found');
                        echo json_encode($retArray);
                        exit;
                    }
                }
            } else {
                $retArray['message'] = $this->lang->line('idcardreport_permissionmethod');
                echo json_encode($retArray);
                exit;
            }
        } else {
            $retArray['message'] = $this->lang->line('idcardreport_permission');
            echo json_encode($retArray);
            exit;
        }
    }

	

}

/* End of file activities.php */
/* Location: .//D/xampp/htdocs/school/mvc/controllers/activities.php */