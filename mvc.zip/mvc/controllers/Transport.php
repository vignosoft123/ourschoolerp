<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transport extends Admin_Controller {
/*
| -----------------------------------------------------
| PRODUCT NAME: 	INILABS SCHOOL MANAGEMENT SYSTEM
| -----------------------------------------------------
| AUTHOR:			INILABS TEAM
| -----------------------------------------------------
| EMAIL:			info@inilabs.net
| -----------------------------------------------------
| COPYRIGHT:		RESERVED BY INILABS IT
| -----------------------------------------------------
| WEBSITE:			http://inilabs.net
| -----------------------------------------------------
*/
	function __construct() {
		parent::__construct();
		$this->load->model("transport_m");
		$this->load->model("student_m");
		$this->load->model("tmember_m");
		$language = $this->session->userdata('lang');
		$this->lang->load('transport', $language);	
	}

	public function index() {
		$sql = "select t.*, d.name as driver_name, a.name as attender_name
				from transport t
				left join user d on d.userID = t.driverID
				left join user a on a.userID = t.attenderID
				order by t.transportID asc";
		$this->data['transports'] = $this->db->query($sql)->result();
		$this->data["subview"] = "transport/index";
		$this->load->view('_layout_main', $this->data);
	}

	protected function rules() {
		$rules = array(
			array(
				'field' => 'route', 
				'label' => $this->lang->line("transport_route"), 
				'rules' => 'trim|required|xss_clean|max_length[128]|callback_unique_route'
			), 
			// array(
			// 	'field' => 'vehicle', 
			// 	'label' => $this->lang->line("transport_vehicle"),
			// 	'rules' => 'trim|required|max_length[11]|xss_clean|numeric|callback_valid_number'
			// ), 
			array(
				'field' => 'fare', 
				'label' => $this->lang->line("transport_fare"),
				'rules' => 'trim|max_length[11]|xss_clean|numeric|callback_valid_number_for_fare'
			),
			array(
				'field' => 'note', 
				'label' => $this->lang->line("transport_note"), 
				'rules' => 'trim|max_length[200]|xss_clean'
			),
			array(
				'field' => 'pickup_point', 
				'label' => $this->lang->line("pickup_point"), 
				'rules' => 'trim|xss_clean',
			)
		);
		return $rules;
	}

	public function add() {

        $driver_user_type_id = $this->db->query("select usertypeID from usertype where usertype='Driver'")->row()->usertypeID;
        $attender_user_type_id = $this->db->query("select usertypeID from usertype where usertype='Attender'")->row()->usertypeID;
		$this->db->where('usertypeID',$driver_user_type_id);
		$this->data["drivers"] = $this->db->get('user')->result();

		$this->db->where('usertypeID',$attender_user_type_id);
		$this->data["attenders"] = $this->db->get('user')->result();

		if($_POST) {
			$rules = $this->rules();
			$this->form_validation->set_rules($rules);
			if ($this->form_validation->run() == FALSE) {
				$this->data['form_validation'] = validation_errors(); 
				$this->data["subview"] = "transport/add";
				$this->load->view('_layout_main', $this->data);			
			} else {
				$array = array(
					"route" => $this->input->post("route"),
					"vehicle" => $this->input->post("vehicle"),
					"fare" => $this->input->post("fare"),
					"note" => $this->input->post("note"),
					"pickupPoint" => $this->input->post("pickup_point"),
					"driverID" => $this->input->post("driverID"),
					"attenderID" => $this->input->post("attenderID"),
					"vehicle_type" => $this->input->post("vehicle_type"),
					"capacity" => $this->input->post("capacity"),
				);

				$this->transport_m->insert_transport($array);
				// echo $this->db->last_query();die;
				$this->session->set_flashdata('success', $this->lang->line('menu_success'));
				redirect(base_url("transport/index"));
			}
		} else {
			$this->data["subview"] = "transport/add";
			$this->load->view('_layout_main', $this->data);
		}
	}
	public function add_new() {

		$this->data['headerassets'] = array(
			'css' => array(
				'assets/select2/css/select2.css',
				'assets/select2/css/select2-bootstrap.css',
				'assets/datepicker/datepicker.css',
				'assets/timepicker/timepicker.css'
			),
			'js' => array(
				'assets/select2/select2.js',
				'assets/datepicker/datepicker.js',
				'assets/timepicker/timepicker.js'
			)
		);
		 
		// echo "<pre>";print_r($_POST);die;
		$year_id = $this->session->userdata('defaultschoolyearID');

		$new_year_data = $this->db->query("select id from pickup_points where year_id=$year_id")->num_rows();
		if($new_year_data > 0){
			$year_id = $this->session->userdata('defaultschoolyearID');
		}else{
			$year_id = 0;
		}


		$this->data["transports"] = $this->db->get('transport')->result();

		$sql = "select p.*,t.route from pickup_points p left join transport t on t.transportID = p.route_id where p.year_id=$year_id";
		$this->data['pickup_points'] = $this->db->query($sql)->result();

		if($_POST) {

				$transportID = $this->input->post("transportID");

				$pickup_id = (int) $this->input->post("pickup_id");

				$array = array(
					"fare" => $this->input->post("fare"),
					"pickupPoint" => $this->input->post("pickup_point"),
					"pickup_time" => $this->input->post("pickup_time"),
					"droping_time" => $this->input->post("drop_time"),
					"route_id" => $transportID,
				);

				if($pickup_id > 0) {
					$this->db->where('id', $pickup_id);
					$this->db->update('pickup_points', $array);
				} else {
					$array["year_id"] = $year_id;
					$this->db->insert('pickup_points', $array);
				}

				$this->session->set_flashdata('success', $this->lang->line('menu_success'));
				redirect(base_url("transport/add_new"));
			//}
		} else {
			$this->data["subview"] = "transport/add_new";
			$this->load->view('_layout_main', $this->data);
		}
	}

	public function toggle_status_pickup_point() {
		header('Content-Type: application/json');
		$id = (int) $this->uri->segment(3);
		if($id) {
			$row = $this->db->where('id', $id)->get('pickup_points')->row();
			if($row) {
				$new_status = ($row->active_status == 1) ? 0 : 1;
				$this->db->where('id', $id);
				$this->db->update('pickup_points', array('active_status' => $new_status));
				echo json_encode(array('success' => true, 'active_status' => $new_status));
				return;
			}
		}
		echo json_encode(array('success' => false));
	}

	public function edit() {
		$id = htmlentities(escapeString($this->uri->segment(3)));

		$driver_user_type_id = $this->db->query("select usertypeID from usertype where usertype='Driver'")->row()->usertypeID;
		$attender_user_type_id = $this->db->query("select usertypeID from usertype where usertype='Attender'")->row()->usertypeID;

		$this->db->where('usertypeID',$driver_user_type_id);
		$this->data["drivers"] = $this->db->get('user')->result();

		$this->db->where('usertypeID',$attender_user_type_id);
		$this->data["attenders"] = $this->db->get('user')->result();

		if((int)$id) {
			$this->data['transport'] = $this->transport_m->get_transport($id);
			if($this->data['transport']) {
				if($_POST) {
					$rules = $this->rules();
					$this->form_validation->set_rules($rules);
					if ($this->form_validation->run() == FALSE) {
						$this->data["subview"] = "transport/edit";
						$this->load->view('_layout_main', $this->data);			
					} else {
						$array = array(
							"route" => $this->input->post("route"),
							"vehicle" => $this->input->post("vehicle"),
							"fare" => $this->input->post("fare"),
							"note" => $this->input->post("note"),
							"pickupPoint" => $this->input->post("pickup_point"),
							"driverID" => $this->input->post("driverID"),
							"vehicle_type" => $this->input->post("vehicle_type"),
							"attenderID" => $this->input->post("attenderID"),
							"capacity" => $this->input->post("capacity"),
						);

						$this->transport_m->update_transport($array, $id);
						$this->session->set_flashdata('success', $this->lang->line('menu_success'));
						redirect(base_url("transport/index"));
					}
				} else {
					$this->data["subview"] = "transport/edit";
					$this->load->view('_layout_main', $this->data);
				}
			} else {
				$this->data["subview"] = "error";
				$this->load->view('_layout_main', $this->data);
			}
		} else {
			$this->data["subview"] = "error";
			$this->load->view('_layout_main', $this->data);
		}	
	}

	public function toggle_status() {
		header('Content-Type: application/json');
		$id = (int) $this->uri->segment(3);
		if($id) {
			$row = $this->transport_m->get_single_transport(array('transportID' => $id));
			if($row) {
				$new_status = ($row->active_status == 1) ? 0 : 1;
				$this->transport_m->update_transport(array('active_status' => $new_status), $id);
				echo json_encode(array('success' => true, 'active_status' => $new_status));
				return;
			}
		}
		echo json_encode(array('success' => false));
	}

	function unique_route() {
		$id = htmlentities(escapeString($this->uri->segment(3)));
		if((int)$id) {
			$transport = $this->transport_m->get_order_by_transport(array("route" => $this->input->post("route"), "transportID !=" => $id));
			if(customCompute($transport)) {
				$this->form_validation->set_message("unique_route", "%s already exists");
				return FALSE;
			}
			return TRUE;
		} else {
			$transport = $this->transport_m->get_order_by_transport(array("route" => $this->input->post("route")));

			if(customCompute($transport)) {
				$this->form_validation->set_message("unique_route", "%s already exists");
				return FALSE;
			}
			return TRUE;
		}	
	}

	function valid_number() {
		if($this->input->post('vehicle') && $this->input->post('vehicle') < 0) {
			$this->form_validation->set_message("valid_number", "%s is invalid number");
			return FALSE;
		}
		return TRUE;
	}

	function valid_number_for_fare() {
		if($this->input->post('fare') && $this->input->post('fare') < 0) {
			$this->form_validation->set_message("valid_number_for_fare", "%s is invalid number");
			return FALSE;
		}
		return TRUE;
	}

	public function update_fare()
{
    $id = $this->input->post('id');
    $fare = $this->input->post('fare');

    if ($id && is_numeric($fare)) { 
        $result = $this->update_fare_query($id, $fare);
        
        if ($result) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'fail']);
        }
    } else {
        echo json_encode(['status' => 'invalid']);
    }
}
public function update_fare_query($id, $fare)
{
    $this->db->where('id', $id);
    return $this->db->update('pickup_points', ['fare' => $fare]);
}



}

/* End of file transport.php */
/* Location: .//D/xampp/htdocs/school/mvc/controllers/transport.php */