<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Global_payment extends Admin_Controller
{
    /*
    | -----------------------------------------------------
    | PRODUCT NAME: 	INILABS SCHOOL MANAGEMENT SYSTEM
    | -----------------------------------------------------
    | AUTHOR:			INILABS TEAM
    | -----------------------------------------------------
    | EMAIL:			info@inilabs.net
    | -----------------------------------------------------
    | COPYRIGHT:		RESERVED BY INILABS IT
    | -----------------------------------------------------
    | WEBSITE:			http://inilabs.net
    | -----------------------------------------------------
    */

    function __construct() {
        parent::__construct();
        $this->load->model("student_m");
        $this->load->model("classes_m");
        $this->load->model("section_m");
        $this->load->model('studentgroup_m');
        $this->load->model('feetypes_m');
        $this->load->model('invoice_m');
        $this->load->model('payment_m');
        $this->load->model('globalpayment_m');
        $this->load->model('weaverandfine_m');
        $this->load->model('maininvoice_m');
        $this->load->model('studentrelation_m');
        $this->load->model('Whatsapp_m'); 
        $language = $this->session->userdata('lang');
        $this->lang->load('global_payment', $language);
        $this->load->library("msg91");

        //  if($this->session->userdata('usertypeID') != 1 || $this->session->userdata('usertypeID') != 5){ //admin & accountant
        //     redirect('student');
        // }
    }

    protected function rules()
    {
        $rules = [
            [
                'field' => 'classesID',
                'label' => $this->lang->line("global_classes"),
                'rules' => 'trim|required|xss_clean|max_length[11]|callback_unique_classes',
            ],
            [
                'field' => 'sectionID',
                'label' => $this->lang->line("global_section"),
                'rules' => 'trim|xss_clean|max_length[11]',
            ],
            [
                'field' => 'studentID',
                'label' => $this->lang->line("global_student"),
                'rules' => 'trim|required|xss_clean|max_length[11]|callback_unique_student',
            ],
        ];

        return $rules;
    }  

    public function index($classesID=0,$studentID=0) {
        $this->data['headerassets'] = array(
            'css' => array(
                'assets/datepicker/datepicker.css',
                'assets/select2/css/select2.css',
                'assets/select2/css/select2-bootstrap.css'
            ),
            'js' => array(
                'assets/datepicker/datepicker.js',
                'assets/select2/select2.js'
            )
        );

        $schoolyearID                   = $this->session->userdata('defaultschoolyearID');
        $this->data['classes']          = $this->classes_m->get_classes();
        $this->data['sections']         = 0;
        $this->data['students']         = [];
        $this->data['globalpayments']   = [];


        $this->data['set_classesID']    = 0;
        $this->data['set_sectionID']    = 0;
        $this->data['set_studentID']    = 0;
        $this->data['set_groupID']      = 0;

        if($this->input->post('classesID') > 0) {
            $this->data['sections'] = $this->section_m->get_order_by_section(array('classesID' => $this->input->post('classesID')));
            if($this->input->post('sectionID') > 0) {
                $this->data['students'] = $this->studentrelation_m->get_order_by_student(array('srclassesID' => $this->input->post('classesID'), 'srsectionID' => $this->input->post('sectionID'), 'srschoolyearID' => $schoolyearID));
            } else {
                $this->data['students'] = $this->studentrelation_m->get_order_by_student(array('srclassesID' => $this->input->post('classesID'), 'srschoolyearID' => $schoolyearID));
            }
        }


        $this->data['single_student'] = [];
        
        if ($_POST || (!empty($classesID) && !empty($studentID) ) ) {
        // print_r($_POST);die;die('1111');

            
            $rules = $this->rules();
            $this->form_validation->set_rules($rules);
            // if ($this->form_validation->run() == FALSE) { 
            //     $this->data["subview"]  = "global_payment/index";
            //     $this->load->view('_layout_main', $this->data);
            // } else {
                $classesID                      = $this->input->post('classesID') ? $this->input->post('classesID') : $classesID;
                $sectionID                      = $this->input->post('sectionID');
                $studentID                      = $this->input->post('studentID') ? $this->input->post('studentID') : $studentID;

                $this->data['set_classesID']    = $classesID; 
                $this->data['set_sectionID']    = $sectionID;
                $this->data['set_studentID']    = $studentID;

                $this->data['feetypes'] = pluck($this->feetypes_m->get_feetypes(), 'feetypes', 'feetypesID');
                $this->data['single_student'] = $this->studentrelation_m->get_single_student(array('srstudentID' => $studentID, 'srschoolyearID' => $schoolyearID));

                $this->payment_m->order_payment('paymentID asc');
                $allPaymentList = $this->payment_m->get_order_by_payment(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

                $allWeaverList = $this->weaverandfine_m->get_order_by_weaverandfine(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

                $this->data['payments'] = $this->generateAllPaymentAmount($allPaymentList);
                $this->data['weavers'] = $this->generateAllWeaverAmount($allWeaverList);
                $this->data['paymenteds'] = $allPaymentList;
                $this->data['weavereds'] = $allWeaverList;

                $this->data['globalpayment_max'] = $this->globalpayment_m->get_max_globalpayment();
                // echo "<pre>";print_r($allPaymentList);die;
                if(customCompute($this->data['single_student'])) {
                    $single_student = $this->data['single_student'];

                    $this->data['single_classes'] = $this->classes_m->get_single_classes(array('classesID' => $single_student->srclassesID));
                    $this->data['single_section'] = $this->section_m->get_single_section(array('sectionID' => $single_student->srsectionID));
                    $this->data['single_group'] = $this->studentgroup_m->get_single_studentgroup(array('studentgroupID' => $single_student->srstudentgroupID));

                    // $this->data['invoices'] = $this->invoice_m->get_order_by_invoice(array('studentID' => $single_student->srstudentID, 'schoolyearID' => $schoolyearID, 'deleted_at' => 1));
                    $this->data['invoices'] = $this->invoice_m->get_order_by_invoice_join_maininvoice( $single_student->srstudentID, $schoolyearID, 1);
                    $this->data['invoicefeetype'] = pluck($this->data['invoices'], 'feetypeID', 'invoiceID');

                     $this->data['schoolyears'] = $this->invoice_m->get_schoolyear();
                    

                    $this->data['globalpayments'] = $this->globalpayment_m->get_order_by_globalpayment(array('schoolyearID' => $schoolyearID,  'studentID' => $single_student->srstudentID));

                    $this->data['paidpayments'] = $this->generateAllPaymentAmountWithGlobalID($allPaymentList);

                    $this->data['weaverandfines'] = pluck($this->weaverandfine_m->get_order_by_weaverandfine(array('studentID' => $single_student->srstudentID, 'schoolyearID' => $schoolyearID)), 'obj', 'paymentID');

                    $users  = $this->data['globalpayments'];
                    $usersArray = (array) $users;
 
                    $lastUser = end($usersArray); 
                    $globalpaymentID = $lastUser->globalpaymentID;
                    // if($_POST){
                    // redirect('Global_payment/print_reciept/'.$single_student->srstudentID.'/'.$globalpaymentID);
                    // }
                } else {
                    $this->data['single_classes'] = [];
                    $this->data['single_section'] = [];
                    $this->data['single_group'] = [];
                    $this->data['invoices'] = [];
                    $this->data['globalpayments'] = [];
                }

                $this->data["subview"] = "global_payment/index";
                $this->load->view('_layout_main', $this->data);
            //}
        } else {
            $this->data["subview"] = "global_payment/index";
            $this->load->view('_layout_main', $this->data);
        }
    }

    private function generateAllPaymentAmount($payments) {
        $returnArray = [];
        if(customCompute($payments)) {
            foreach ($payments as $payment) {
                $returnArray[$payment->invoiceID] = isset($returnArray[$payment->invoiceID]) ?  $returnArray[$payment->invoiceID] + $payment->paymentamount :  $payment->paymentamount; 
            }
        }

        return $returnArray;
    }

    private function generateAllPaymentAmountWithGlobalID($payments) {
        $returnArray = [];
        $weaverandfine = pluck($this->weaverandfine_m->get_weaverandfine(), 'obj', 'paymentID');

        if(customCompute($payments)) {

             $invoiceIDs = array_map(function($p) {
                        return $p->invoiceID;
                    }, $payments);

                    $invoiceIDs = array_unique($invoiceIDs);
                    $this->db->select('invoiceID, feetype');
                    $this->db->from('invoice');
                    $this->db->where_in('invoiceID', $invoiceIDs);
                    $query = $this->db->get();
                    $invoices = $query->result();
                    $invoiceMap = [];
                    foreach ($invoices as $inv) {
                        $invoiceMap[$inv->invoiceID] = $inv->feetype;
                    }

            foreach ($payments as $payment) {
                $returnArray['paid'][$payment->globalpaymentID] = isset($returnArray['paid'][$payment->globalpaymentID]) ?  $returnArray['paid'][$payment->globalpaymentID] + $payment->paymentamount :  $payment->paymentamount;

                if(isset($returnArray['paid'][$payment->globalpaymentID])) {
                    if(isset($weaverandfine[$payment->paymentID])) {
                        if(isset($returnArray['weaver'][$payment->globalpaymentID])) {
                            $returnArray['weaver'][$payment->globalpaymentID] += $weaverandfine[$payment->paymentID]->weaver; 
                        } else {
                            $returnArray['weaver'][$payment->globalpaymentID] = $weaverandfine[$payment->paymentID]->weaver; 
                        }

                        if(isset($returnArray['fine'][$payment->globalpaymentID])) {
                            $returnArray['fine'][$payment->globalpaymentID] += $weaverandfine[$payment->paymentID]->fine; 
                        } else {
                            $returnArray['fine'][$payment->globalpaymentID] = $weaverandfine[$payment->paymentID]->fine; 
                        }
                    }

                    if(!isset($returnArray['paiddate'][$payment->globalpaymentID])) {
                        $returnArray['paiddate'][$payment->globalpaymentID] = $payment->paymentdate;
                    }

                    // if(!isset($returnArray['invoice_id'][$payment->globalpaymentID])) {
                    //     $returnArray['invoice_id'][$payment->globalpaymentID] = $payment->invoiceID;
                    // }

                     if (!isset($returnArray['invoice_id'][$payment->globalpaymentID])) {
                        // Get feetype from invoiceMap using invoiceID
                        $feetypeName = isset($invoiceMap[$payment->invoiceID]) ? $invoiceMap[$payment->invoiceID] : '';
                        $returnArray['invoice_id'][$payment->globalpaymentID] = $feetypeName;
                    }
                   

                }
            }
        }

        return $returnArray;
    }

    private function generateAllWeaverAmount($weaverandfines) {
        $returnArray = [];
        if(customCompute($weaverandfines)) {
            foreach ($weaverandfines as $weaverandfine) {
                $returnArray[$weaverandfine->invoiceID] = isset($returnArray[$weaverandfine->invoiceID]) ?  $returnArray[$weaverandfine->invoiceID] + $weaverandfine->weaver :  $weaverandfine->weaver; 
            }
        }
        return $returnArray;
    }

    public function unique_classes() {
        if ($this->input->post('classesID') == 0) {
            $this->form_validation->set_message("unique_classes", "The %s field is required");
            return FALSE;
        }
        return TRUE;
    }

    public function unique_student() {
        if($this->input->post('studentID') == 0) {
            $this->form_validation->set_message("unique_student", "The %s field is required");
            return false;
        }
        return true;
    }

    public function sectioncall() {
        $id = $this->input->post('id');
        if ((int) $id) {
            $allsection = $this->section_m->get_order_by_section([ "classesID" => $id ]);
            echo "<option value='0'>", $this->lang->line("global_select_section"), "</option>";
            foreach ($allsection as $value) {
                echo "<option value=\"$value->sectionID\">", $value->section, "</option>";
            }
        } else {
            echo "<option value='0'>", $this->lang->line("global_select_section"), "</option>";
        }
    }

    public function studentcall() {
        $classesID = $this->input->post('classesID');
        $sectionID = $this->input->post('sectionID');
        $schoolyearID = $this->session->userdata('defaultschoolyearID');

        if ((int) $classesID && (int) $sectionID) {
            if($sectionID == 0) {
                $allstudent = $this->studentrelation_m->get_order_by_student([ "srclassesID" => $classesID, 'srschoolyearID' => $schoolyearID ]);
            } else {
                $allstudent = $this->studentrelation_m->get_order_by_student([ "srclassesID" => $classesID, 'srsectionID' => $sectionID, 'srschoolyearID' => $schoolyearID ]);
            }

            echo "<option value='0'>", $this->lang->line("global_select_student"), "</option>";
            foreach ($allstudent as $value) {
                echo "<option value=\"$value->srstudentID\">", $value->srname.' - '.$this->lang->line('global_roll').' - '.$value->srroll, "</option>";
            }
        } elseif((int) $classesID) {
            $allstudent = $this->studentrelation_m->get_order_by_student([ "srclassesID" => $classesID, 'srschoolyearID' => $schoolyearID ]);
            echo "<option value='0'>", $this->lang->line("global_select_student"), "</option>";
            foreach ($allstudent as $value) {
                echo "<option value=\"$value->srstudentID\">", $value->srname.' - '.$this->lang->line('global_roll').' - '.$value->srroll, "</option>";
            }
        } else {
            echo "<option value='0'>", $this->lang->line("global_select_section"), "</option>";
        }
    }

    protected function paymentRules() {
        $rules = array(
            array(
                'field' => 'studentID',
                'label' => $this->lang->line("global_student"),
                'rules' => 'trim|required|xss_clean|numeric|max_length[11]'
            ),
            array(
                'field' => 'classesID',
                'label' => $this->lang->line("global_classes"),
                'rules' => 'trim|required|xss_clean|numeric|max_length[11]'
            ),
            array(
                'field' => 'invoicename',
                'label' => $this->lang->line("global_invoice_name"),
                'rules' => 'trim|required|xss_clean|max_length[127]'
            ),
            array(
                'field' => 'invoicedescription',
                'label' => $this->lang->line("global_description"),
                'rules' => 'trim|xss_clean|max_length[127]'
            ),
            array(
                'field' => 'invoicenumber',
                'label' => $this->lang->line("global_invoice_number"),
                'rules' => 'trim|required|xss_clean|min_length[6]'
            ),
            array(
                'field' => 'paymentyear',
                'label' => $this->lang->line("global_payment_year"),
                'rules' => 'trim|required|numeric|xss_clean|max_length[4]'
            ),
            array(
                'field' => 'payment_status',
                'label' => $this->lang->line("global_payment_status"),
                'rules' => 'trim|required|xss_clean|max_length[7]'
            ),
            array(
                'field' => 'payment_type',
                'label' => $this->lang->line("global_payment_type"),
                'rules' => 'trim|required|xss_clean|max_length[6]'
            ),
            // array(
            //     'field' => 'paid',
            //     'label' => $this->lang->line("global_paid"),
            //     'rules' => 'trim|xss_clean|max_length[10]|callback_unique_paidweaverfine'
            // )
        );
        return $rules;
    }

    public function unique_paidweaverfine() {
        $paids = $this->input->post('paid');
        $weavers = $this->input->post('weaver');
        $fines = $this->input->post('fine');

        $max_value = 10; 
        $paidRequiredStatus = FALSE;
        $weaverRequiredStatus = FALSE;
        $fineRequiredStatus = FALSE;
        
        if(customCompute($paids)) {
            foreach ($paids as $paid) {
                if($paid['value'] != '') {
                    if((float) $paid['value']) {
                        if(strlen($paid['value']) <= $max_value && strlen($paid['value']) >= 0) {
                            $paidRequiredStatus = TRUE;
                        } else {
                            $this->form_validation->set_message("unique_paidweaverfine", "%s cannot exceed ".$max_value." characters in length.");
                            return FALSE;
                        } 
                    } else {
                        $this->form_validation->set_message("unique_paidweaverfine", "%s must contain only numbers.");
                        return FALSE;
                    }
                }
            }
        }

        if(customCompute($weavers)) {
            foreach ($weavers as $weaver) {
                if($weaver['value'] != '') {
                    if((float) $weaver['value']) {
                        if(strlen($weaver['value']) <= $max_value && strlen($weaver['value']) >= 0) {
                            $weaverRequiredStatus = TRUE;
                        } else {
                            $this->form_validation->set_message("unique_paidweaverfine", "%s cannot exceed ".$max_value." characters in length.");
                            return FALSE;
                        } 
                    } else {
                        $this->form_validation->set_message("unique_paidweaverfine", "%s must contain only numbers.");
                        return FALSE;
                    }
                }
            }
        }

        if(customCompute($fines)) {
            foreach ($fines as $fine) {
                if($fine['value'] != '') {
                    if((float) $fine['value']) {
                        if(strlen($fine['value']) <= $max_value && strlen($fine['value']) >= 0) {
                            $fineRequiredStatus = TRUE;
                        } else {
                            $this->form_validation->set_message("unique_paidweaverfine", "%s cannot exceed ".$max_value." characters in length.");
                            return FALSE;
                        } 
                    } else {
                        $this->form_validation->set_message("unique_paidweaverfine", "%s must contain only numbers.");
                        return FALSE;
                    }
                }
            }
        }

        if($paidRequiredStatus || $weaverRequiredStatus || $fineRequiredStatus) {
            if($this->session->flashdata('paymentGenerateStatus')) {
                return FALSE;
                $this->form_validation->set_message("unique_paidweaverfine", "%s is required.");
            }

            return TRUE;
        } else {
            $this->form_validation->set_message("unique_paidweaverfine", "%s is required.");
            return FALSE;
        }
    }

    public function paymentSend() {
        $retArray['status'] = FALSE;
        $retArray['message'] = '';
        // echo "<pre>";print_r($_POST);die;
        if($_POST) {
            $rules = $this->paymentRules();
            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() == FALSE) {
                $retArray = $this->form_validation->error_array();
                $retArray['status'] = FALSE;
                echo json_encode($retArray);
                exit;
            } else {
                $schoolyearID       = $this->session->userdata('defaultschoolyearID');
 
                $paids              = $this->input->post('paid');
                $weavers            = $this->input->post('weaver');
                $fines              = $this->input->post('fine');
                
                $studentID          = $this->input->post('studentID');
                $classesID          = $this->input->post('classesID');
                $invoicename        = $this->input->post('invoicename');
                $invoicedescription = $this->input->post('invoicedescription');
                $invoicenumber      = $this->input->post('invoicenumber');
                $paymentyear        = $this->input->post('paymentyear');
                $payment_status     = $this->input->post('payment_status');
                $payment_type       = $this->input->post('payment_type');
                $sectionID          = 0;
                
                $globalpayment['classesID']         = $classesID;
                $globalpayment['studentID']         = $studentID;
                $globalpayment['clearancetype']     = $payment_status;
                $globalpayment['invoicename']       = $invoicename;
                $globalpayment['invoicedescription']= $invoicedescription;
                $globalpayment['paymentyear']       = $paymentyear;
                $globalpayment['schoolyearID']      =  !empty($this->input->post('schoolyearID')) ? $this->input->post('schoolyearID') : $schoolyearID;

                $payment_date = $this->input->post('created_date') ? date("Y-m-d", strtotime($this->input->post('created_date'))) : date("Y-m-d");

                // Extract day, month, year
        $day1 = date("d", strtotime($payment_date));
        $month1 = date("m", strtotime($payment_date));
        $year1 = date("Y", strtotime($payment_date));

                if($studentID) {
                    $student = $this->studentrelation_m->get_single_student(array('srstudentID' => $studentID, 'srschoolyearID' => $schoolyearID));
                    if(customCompute($student)) {
                        $sectionID = $student->srsectionID;
                    }
                }

                $globalpayment['sectionID'] = $sectionID;
                $this->globalpayment_m->insert_globalpayment($globalpayment);
                $globalLastID = $this->db->insert_id();

                if($globalLastID) { 
                    $payments = [];
                    $weaverandfines = [];
                    $j = (customCompute($paids) - 1);
                    
                    for($i = 0; $i <= $j; $i++) {
                        $expPaidField = explode('-', $paids[$i]['paidFieldID']);
                        $payments[$i] = array(
                            'schoolyearID' =>  !empty($this->input->post('schoolyearID')) ? $this->input->post('schoolyearID') : $schoolyearID,
                            'invoiceID' => $expPaidField[1],                
                            'studentID' => $studentID,                
                            'paymentamount' => ($paids[$i]['value'] == '') ? NULL : $paids[$i]['value'],                
                            'paymenttype' => ucfirst($payment_type),                
                            'paymentdate' => $payment_date,
                            'paymentday' => $day1,//date('d'),                
                            'paymentmonth' => $month1,//date('m'),                
                            'paymentyear' => $year1,//date('Y'),
                            'userID' => $this->session->userdata('loginuserID'),
                            'usertypeID' => $this->session->userdata('usertypeID'),
                            'uname' => $this->session->userdata('name'),
                            'transactionID' => 'CASHANDCHEQUE'.random19(),      
                            'globalpaymentID' => $globalLastID,    
                            'is_previous_year_amount'  => $this->input->post('is_previous_year_amount') ?? 0         
                        );

                        if(isset($weavers[$i]['value']) || isset($fines[$i]['value'])) {
                            if($weavers[$i]['value'] > 0 && $fines[$i]['value'] > 0) {
                                $weaverandfines[$i] = array(
                                    'weaver' => $weavers[$i]['value'],
                                    'fine' => $fines[$i]['value'],
                                    'globalpaymentID' => $globalLastID,
                                    'invoiceID' => $expPaidField[1],
                                    'studentID' => $studentID,
                                    'schoolyearID' => $schoolyearID,
                                );
                            } elseif($weavers[$i]['value'] > 0) {
                                $weaverandfines[$i] = array(
                                    'weaver' => $weavers[$i]['value'],
                                    'fine' => 0,
                                    'globalpaymentID' => $globalLastID,
                                    'invoiceID' => $expPaidField[1],
                                    'studentID' => $studentID,
                                    'schoolyearID' => $schoolyearID,
                                );
                            } elseif($fines[$i]['value'] > 0) {
                                $weaverandfines[$i] = array(
                                    'weaver' => 0,
                                    'fine' => $fines[$i]['value'],
                                    'globalpaymentID' => $globalLastID,
                                    'invoiceID' => $expPaidField[1],
                                    'studentID' => $studentID,
                                    'schoolyearID' => $schoolyearID,
                                );
                            }
                        }
                    }

                    $insertPaymentIDS = [];
                    if(customCompute($payments)) {
                        $entered_payment  = 0;
                        foreach($payments as $payment) {
                            $this->payment_m->insert_payment($payment);
                            $paymentID = $this->db->insert_id();
                            $insertPaymentIDS[$payment['invoiceID']] = $paymentID;

                            $entered_payment += $payment['paymentamount'];
                        }
                        $retArray['status'] = TRUE;
                    }

                    if(customCompute($weaverandfines)) {
                        foreach ($weaverandfines as $weaverandfine) {
                            if(isset($insertPaymentIDS[$weaverandfine['invoiceID']])) {
                                $weaverandfine['paymentID'] = $insertPaymentIDS[$weaverandfine['invoiceID']];
                                $this->weaverandfine_m->insert_weaverandfine($weaverandfine);
                            }
                        }
                        $retArray['status'] = TRUE;
                    }

                    $invoices = $this->invoice_m->get_order_by_invoice(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID, 'deleted_at' => 1));

                    $allPaymentList = $this->payment_m->get_order_by_payment(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

                    $allWeaverList = $this->weaverandfine_m->get_order_by_weaverandfine(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

                    $payments = $this->generateAllPaymentAmount($allPaymentList);
                    $weavers = $this->generateAllWeaverAmount($allWeaverList);

                    $totalInvoiceAmount = 0;
                    if(customCompute($invoices)) {
                        foreach ($invoices as $invoice) {
                             $totalInvoiceAmount += ($invoice->amount - (($invoice->amount/100)*$invoice->discount));
                        }
                    }

                    $totalPaymentAmount = 0;
                    if(customCompute($allPaymentList)) {
                        foreach ($allPaymentList as $payment) {
                            $totalPaymentAmount += $payment->paymentamount;
                        }
                    }

                    $totalWeaverAmount = 0;
                    if(customCompute($allWeaverList)) {
                        foreach ($allWeaverList as $weaver) {
                            $totalWeaverAmount += $weaver->weaver;
                        }
                    }

                    $student->balance_amount = number_format(($totalInvoiceAmount - ($totalPaymentAmount + $totalWeaverAmount)), 2, '.', '');

                    for($i = 0; $i <= $j; $i++) {
                        $expPaidField = explode('-', $paids[$i]['paidFieldID']);
                        if(isset($expPaidField[1]) && isset($invoices[$i]) && customCompute($invoices[$i]) && ($expPaidField[1] == $invoices[$i]->invoiceID)) {
                            $invoiceID = $expPaidField[1];
                            $invoice = $invoices[$i]; 

                            $totalPaymentWeaver = 0;
                            $totalAmount = 0;
                            $status = 0;

                            if(isset($payments[$invoiceID])) {
                                $totalPaymentWeaver += $payments[$invoiceID];
                            }

                            if(isset($weavers[$invoiceID])) {
                                $totalPaymentWeaver += $weavers[$invoiceID];
                            }

                            if($invoice->discount > 0) {
                                $totalAmount = ($invoice->amount - (($invoice->amount/100)*$invoice->discount));
                            } else {
                                $totalAmount = $invoice->amount;
                            }

                            if(number_format($totalAmount, 2, '.', '') == number_format($totalPaymentWeaver, 2, '.', '')) {
                                $status = 2;
                            } elseif((number_format($totalAmount, 2, '.', '') > number_format($totalPaymentWeaver, 2, '.', '')) && (number_format($totalPaymentWeaver, 2, '.', '') != number_format(0, 2, '.', ''))) {
                                $status = 1;
                            }

                            $this->invoice_m->update_invoice(array('paidstatus' => $status), $invoiceID);
                            if(!isset($student->category)) {
                                $student->category = $invoice->feetype;
                            }
                        }
                    }

                    $maininvoices = $this->maininvoice_m->get_order_by_maininvoice(array('maininvoiceschoolyearID' => $schoolyearID, 'maininvoicestudentID' => $studentID, 'maininvoicedeleted_at' => 1));

                    if(customCompute($maininvoices)) {
                        $invoices = $this->invoice_m->get_order_by_invoice(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID, 'deleted_at' => 1));
                        $invoices = pluck_multi_array($invoices, 'obj', 'maininvoiceID');
                        foreach ($maininvoices as $maininvoice) {
                            if(isset($invoices[$maininvoice->maininvoiceID])) {
                                $maininvoicecheckstatus = [];
                                $maininvoicecheckstatusfordueorpar = [];
                                foreach ($invoices[$maininvoice->maininvoiceID] as $invoice) {
                                    if($invoice->paidstatus == 2) {
                                        $maininvoicecheckstatus[] = TRUE; 
                                    } else {
                                        $maininvoicecheckstatus[] = FALSE; 
                                    }

                                    if($invoice->paidstatus == 1) {
                                        $maininvoicecheckstatusfordueorpar[] = TRUE;
                                    } else {
                                        $maininvoicecheckstatusfordueorpar[] = FALSE;
                                    }
                                }


                                if(in_array(FALSE, $maininvoicecheckstatus)) {
                                    if(in_array(TRUE, $maininvoicecheckstatusfordueorpar)) {
                                        $this->maininvoice_m->update_maininvoice(array('maininvoicestatus' => 1), $maininvoice->maininvoiceID);
                                    } else {
                                        $this->maininvoice_m->update_maininvoice(array('maininvoicestatus' => 0), $maininvoice->maininvoiceID);
                                    }
                                } else {
                                    $this->maininvoice_m->update_maininvoice(array('maininvoicestatus' => 2), $maininvoice->maininvoiceID);
                                }
                            }
                        }
                    }
                }

                // print_r($entered_payment);die;
                $student->paidamount = $entered_payment;
                // $student->category = $invoice->feetype;
                $student->date = date("d-m-Y");
                // $student->phone = $student_info->phone;
                // echo "<pre>";print_r($student);die;
                if (notification_enabled('fee_payment', 'sms')) {
                    $sms_status = $this->userConfigSMS($student, $getway='msg91');
                }

                if (!empty($_POST['send_whatsapp']) && notification_enabled('fee_payment', 'whatsapp')) {
                    $whatsapp_config_send = $this->Whatsapp_m->whatsapp_config_send($student);
                    if(empty($whatsapp_config_send)){
                        $messege =  "phone or template or params missing!, So Whatsapp Not Sent";
                    }
                }

                $this->session->set_flashdata('paymentGenerateStatus', TRUE);
                $this->session->set_flashdata('paymentGenerateGlobalLastID', $globalLastID);
                $this->session->set_flashdata('paymentGenerateLastStudentID', $studentID);
                $this->session->set_flashdata('success', $this->lang->line('menu_success'));

                $retArray['sms_resp'] = $sms_status;
                $retArray['studentID'] = $studentID;
                $retArray['globalLastID'] = $globalLastID;
                $retArray['message'] = $messege;
                echo json_encode($retArray);
                exit;
            }
        } else {
            $retArray['message'] = 'Something wrong';
            echo json_encode($retArray);
            exit;
        }
    }


    

    
    private function userConfigSMS($user, $getway='msg91') { 
        // echo 'asdaa';die;
        $this->load->model('mailandsmstemplate_m');
		$this->load->model('mailandsmstemplatetag_m');
        $cnt = $this->db->query("select * from setting where fieldoption ='is_fee_sms' and value='1' ")->num_rows();
        // echo $cnt;die;
        if($cnt > 0){
	    $template_id = 0;
        $template = $this->mailandsmstemplate_m->get_mailandsmstemplate(5);
        $template_id = $template->templ_id;
        $message = $template->template;
        // print_r($user);die;
		if($user) {
			$userTags = $this->mailandsmstemplatetag_m->get_order_by_mailandsmstemplatetag(array('usertypeID' => 3));
			$message = $this->tagConvertor($userTags, $user, $message, 'SMS');
			if($user->phone) {
				$send = $this->allgetway_send_message($getway, $user->phone, $message, $template_id);
			} else {
				// $send = array('check' => TRUE);
				// return $send;
			}
		}
        return $send;
    }
	}
	
	private function tagConvertor($userTags, $user, $message, $sendType) { 
		if(customCompute($userTags)) {
		    $this->load->model('setting_m');
		    $this->data['setting'] = $this->setting_m->get_setting();
		    $school_name = (isset($this->data['setting']->sname)) ? $this->data['setting']->sname : "";
			foreach ($userTags as $key => $userTag) {
				if($userTag->tagname == '{{paid_amount}}') {
					if($user->paidamount) {
						$message = str_replace('{{paid_amount}}', $user->paidamount, $message);
					} else {
						$message = str_replace('{{paid_amount}}', ' ', $message);
					}
				} elseif($userTag->tagname == '{{category}}') {
					if($user->category) {
						$message = str_replace('{{category}}', $user->category, $message);
					} else {
						$message = str_replace('{{category}}', ' ', $message);
					}
				}
				elseif($userTag->tagname == '{{school_name}}') {
					$message = str_replace("{{school_name}}", $school_name, $message);
				}
               elseif($userTag->tagname == '{{student_name}}') {
					$message = str_replace("{{student_name}}",$user->srname, $message);
				}
			}
		}

		if(isset($user->balance_amount)) {
			$message = str_replace('{{balance_amount}}', $user->balance_amount, $message);
		} else {
			$message = str_replace('{{balance_amount}}', '0.00', $message);
		}

		return $message;
	}
	
	private function allgetway_send_message($getway, $to, $message, $template_id=0) { 
		$res = $this->msg91->send($to, $message, $template_id);
        return $res;
	}

    public function print_reciept($studentID,$globalpaymentID,$prev_schoolyearID=0) {
        $this->data['headerassets'] = array(
            'css' => array(
                'assets/datepicker/datepicker.css',
                'assets/select2/css/select2.css',
                'assets/select2/css/select2-bootstrap.css'
            ),
            'js' => array(
                'assets/datepicker/datepicker.js',
                'assets/select2/select2.js'
            )
        );

        if(!empty($prev_schoolyearID)){
        $schoolyearID   = $prev_schoolyearID;
        }else{
        $schoolyearID   = $this->session->userdata('defaultschoolyearID'); 

        }
        $this->data['single_student'] = [];
        $this->data['single_student'] = $this->studentrelation_m->get_single_student(array('srstudentID' => $studentID, 'srschoolyearID' => $schoolyearID));
        $cnt = $this->db->query("select * from setting where fieldoption ='isrecieptphone' and value='1' ")->num_rows();
        $this->data['is_phone_display'] = $cnt;

        $this->payment_m->order_payment('paymentID asc');
        $allPaymentList = $this->payment_m->get_order_by_payment(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

        $allWeaverList = $this->weaverandfine_m->get_order_by_weaverandfine(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

        $this->data['payments'] = $this->generateAllPaymentAmount($allPaymentList);
        $this->data['weavers'] = $this->generateAllWeaverAmount($allWeaverList);
        $this->data['paymenteds'] = $allPaymentList;
        $this->data['weavereds'] = $allWeaverList;

        $this->data['globalpayment_max'] = $this->globalpayment_m->get_max_globalpayment();
        $this->data['feetypes'] = pluck($this->feetypes_m->get_feetypes(), 'feetypes', 'feetypesID');

        if(customCompute($this->data['single_student'])) {
            $single_student = $this->data['single_student'];

            $this->data['single_classes'] = $this->classes_m->get_single_classes(array('classesID' => $single_student->srclassesID));
            $this->data['single_section'] = $this->section_m->get_single_section(array('sectionID' => $single_student->srsectionID));
            $this->data['single_group'] = $this->studentgroup_m->get_single_studentgroup(array('studentgroupID' => $single_student->srstudentgroupID));

            // $this->data['invoices'] = $this->invoice_m->get_order_by_invoice(array('studentID' => $single_student->srstudentID, 'schoolyearID' => $schoolyearID, 'deleted_at' => 1));

            $this->data['invoices'] = $this->invoice_m->get_order_by_invoice_join_maininvoice( $single_student->srstudentID, $schoolyearID, 1);
 

            $this->data['invoicefeetype'] = pluck($this->data['invoices'], 'feetypeID', 'invoiceID');

            $this->data['globalpayment'] = $this->globalpayment_m->get_order_by_globalpayment(array('globalpaymentID' => $globalpaymentID,  'schoolyearID' => $schoolyearID,   'studentID' => $single_student->srstudentID));
            // echo "<pre>";print_r($this->data['globalpayment'] );die;

            $this->data['paidpayments'] = $this->generateAllPaymentAmountWithGlobalID($allPaymentList);

            $this->data['weaverandfines'] = pluck($this->weaverandfine_m->get_order_by_weaverandfine(array('studentID' => $single_student->srstudentID, 'schoolyearID' => $schoolyearID)), 'obj', 'paymentID');
        } else {
            $this->data['single_classes'] = [];
            $this->data['single_section'] = [];
            $this->data['single_group'] = [];
            $this->data['invoices'] = [];
            $this->data['globalpayments'] = [];
        }
        
        $this->data['globalpayments'] = $this->globalpayment_m->get_order_by_globalpayment(array('schoolyearID' => $schoolyearID,  'studentID' => $single_student->srstudentID));
        $this->data['paidpayments'] = $this->generateAllPaymentAmountWithGlobalID($allPaymentList);
                $this->data["subview"] = "common_views/invoice";
                $this->load->view('_layout_main', $this->data);
             
         
    }


    public function updateMultiple() {
        $invoiceIDs = $this->input->post('invoiceIDs');
        $maininvoiceIDs = $this->input->post('maininvoiceIDs');
    
        if (!empty($invoiceIDs)) {
            $this->invoice_m->updateInvoices($invoiceIDs);
        }
    
        if (!empty($maininvoiceIDs)) {
            $this->invoice_m->updateMainInvoices($maininvoiceIDs);
        }
    
        echo "Selected invoices deleted successfully (only if no payments were found).";
    }
    
    public function updateSingle() {
        $invoiceID = $this->input->post('invoiceID');
        $maininvoiceID = $this->input->post('maininvoiceID');
    
        if ($invoiceID) {
            $this->invoice_m->updateInvoice($invoiceID);
        }
    
        if ($maininvoiceID) {
            $this->invoice_m->updateMainInvoice($maininvoiceID);
        }
    
        echo "Invoice deleted successfully (only if no payments were found).";
    }

    public function get_prev_year_data()
{
    $schoolyearID = $this->input->post('schoolyearID');
    $studentID = $this->input->post('studentID');
    $set_classesID = $this->input->post('set_classesID');
    $this->data['inv_name'] =  $this->input->post('inv_name');

    $this->data['set_classesID'] = $set_classesID;
    $this->data['set_studentID'] = $studentID;
    $this->data['feetypes'] = pluck($this->feetypes_m->get_feetypes(), 'feetypes', 'feetypesID');

    
     $this->payment_m->order_payment('paymentID asc');
    $allPaymentList = $this->payment_m->get_order_by_payment(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

    $allWeaverList = $this->weaverandfine_m->get_order_by_weaverandfine(array('studentID' => $studentID, 'schoolyearID' => $schoolyearID));

    $this->data['payments'] = $this->generateAllPaymentAmount($allPaymentList);
    $this->data['weavers'] = $this->generateAllWeaverAmount($allWeaverList);
    $this->data['schoolyearID'] = $schoolyearID;
    $this->data['invoices'] = $this->invoice_m->get_order_by_invoice_join_maininvoice( $studentID, $schoolyearID, 1);

    // Load and return view content
    $this->load->view('global_payment/prev_year_data', $this->data); // this is the partial view
}

}

